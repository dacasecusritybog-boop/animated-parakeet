package com.dacatech.cotizaciones;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import org.json.JSONObject;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.contentstream.PDFStreamEngine;
import com.tom_roush.pdfbox.contentstream.operator.DrawObject;
import com.tom_roush.pdfbox.contentstream.operator.Operator;
import com.tom_roush.pdfbox.contentstream.operator.state.Concatenate;
import com.tom_roush.pdfbox.contentstream.operator.state.Restore;
import com.tom_roush.pdfbox.contentstream.operator.state.Save;
import com.tom_roush.pdfbox.contentstream.operator.state.SetGraphicsStateParameters;
import com.tom_roush.pdfbox.contentstream.operator.state.SetMatrix;
import com.tom_roush.pdfbox.cos.COSBase;
import com.tom_roush.pdfbox.cos.COSName;
import com.tom_roush.pdfbox.pdmodel.graphics.PDXObject;
import com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject;
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject;
import com.tom_roush.pdfbox.text.TextPosition;
import com.tom_roush.pdfbox.util.Matrix;
import org.json.JSONArray;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import java.security.MessageDigest;

import java.io.File;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1001;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B1117);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets.consumeSystemWindowInsets();
            }
        });
        root.requestApplyInsets();
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);

        web.addJavascriptInterface(new Object() {
            private final String PREF = "dacatech_auth";
            private SharedPreferences prefs() { return getSharedPreferences(PREF, MODE_PRIVATE); }
            private String hash(String value) {
                try {
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    byte[] bytes = md.digest(value.getBytes("UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    for (byte b : bytes) sb.append(String.format("%02x", b & 0xff));
                    return sb.toString();
                } catch (Exception e) { return ""; }
            }
            @JavascriptInterface public synchronized String currentUser() {
                return prefs().getString("current_user", "");
            }
            @JavascriptInterface public synchronized String register(String username, String password) {
                String u = username == null ? "" : username.trim().toLowerCase();
                String pw = password == null ? "" : password;
                if (u.length() < 3) return "Usuario demasiado corto";
                if (pw.length() < 6) return "La contraseña debe tener al menos 6 caracteres";
                SharedPreferences p = prefs();
                if (p.contains("user_" + u)) return "Ese usuario ya existe";
                p.edit().putString("user_" + u, hash(pw)).putString("current_user", u).commit();
                return "OK";
            }
            @JavascriptInterface public synchronized String login(String username, String password) {
                String u = username == null ? "" : username.trim().toLowerCase();
                String stored = prefs().getString("user_" + u, "");
                if (stored.length() == 0 || !stored.equals(hash(password == null ? "" : password))) return "Usuario o contraseña incorrectos";
                prefs().edit().putString("current_user", u).commit();
                return "OK";
            }
            @JavascriptInterface public synchronized String changePassword(String username, String oldPw, String newPw) {
                String u = username == null ? "" : username.trim().toLowerCase();
                String stored = prefs().getString("user_" + u, "");
                if (stored.length() == 0 || !stored.equals(hash(oldPw == null ? "" : oldPw))) return "La contraseña actual es incorrecta";
                if (newPw == null || newPw.length() < 6) return "La nueva contraseña debe tener al menos 6 caracteres";
                prefs().edit().putString("user_" + u, hash(newPw)).commit();
                return "OK";
            }
            @JavascriptInterface public synchronized void logout() {
                prefs().edit().remove("current_user").commit();
            }
                    @JavascriptInterface public synchronized void setLastUser(String u) {
                prefs().edit().putString("last_user", u == null ? "" : u).commit();
            }
            @JavascriptInterface public synchronized String getLastUser() {
                return prefs().getString("last_user", "");
            }
            @JavascriptInterface public synchronized void setProfile(String u, String json) {
                prefs().edit().putString("profile_" + (u == null ? "" : u.trim().toLowerCase()), json == null ? "" : json).commit();
            }
            @JavascriptInterface public synchronized String getProfile(String u) {
                return prefs().getString("profile_" + (u == null ? "" : u.trim().toLowerCase()), "");
            }
        }, "Auth");

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void extract(final String b64) {
                new Thread(new Runnable() { @Override public void run() {
                    String out = "";
                    try {
                        PDFBoxResourceLoader.init(getApplicationContext());
                        byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                        PDDocument doc = PDDocument.load(data);
                        try { out = readPdf(doc); } finally { doc.close(); }
                    } catch (Throwable e) {
                        try {
                            JSONObject o = new JSONObject();
                            String m = String.valueOf(e.getMessage());
                            o.put("err", m.length() == 0 ? "error" : m);
                            out = o.toString();
                        } catch (Exception ex) { out = "{\"err\":\"error\"}"; }
                    }
                    final String js = "window.onPdfData(" + JSONObject.quote(out) + ")";
                    runOnUiThread(new Runnable() { @Override public void run() { web.evaluateJavascript(js, null); } });
                }}).start();
            }
        }, "PdfImp");

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void sharePdf(final String json, final String via, final String to, final String subject) {
                doSharePdf(json, via, to, subject);
            }
            @JavascriptInterface public void printPage(final String title) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    String job = title.replaceAll("[^\\p{L}\\p{N} ._-]", "_");
                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.NA_LETTER)
                        .setMinMargins(new PrintAttributes.Margins(400, 400, 400, 400))
                        .build();
                    pm.print(job, web.createPrintDocumentAdapter(job), attrs);
                }});
            }
            @JavascriptInterface public void shareText(final String text) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Enviar cotización"));
                }});
            }
            @JavascriptInterface public void shareWhatsApp(final String text) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    i.setPackage("com.whatsapp");
                    try { startActivity(i); }
                    catch (Exception e) { i.setPackage(null); startActivity(Intent.createChooser(i, "Enviar cotización")); }
                }});
            }
            @JavascriptInterface public void sendEmail(final String to, final String subject, final String body) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
                    if (to != null && to.length() > 0) i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                    i.putExtra(Intent.EXTRA_SUBJECT, subject);
                    i.putExtra(Intent.EXTRA_TEXT, body);
                    try { startActivity(Intent.createChooser(i, "Enviar por correo")); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "No hay app de correo", Toast.LENGTH_LONG).show(); }
                }});
            }
        }, "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !"file".equals(u.getScheme()) && !"about".equals(u.getScheme());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { result.confirm(); } })
                    .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { result.cancel(); } })
                    .setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override public void onCancel(DialogInterface d) { result.cancel(); } })
                    .show();
                return true;
            }
            @Override public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { result.confirm(); } })
                    .setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override public void onCancel(DialogInterface d) { result.confirm(); } })
                    .show();
                return true;
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try { startActivityForResult(params.createIntent(), REQ_FILE); }
                catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private static class WordStripper extends PDFTextStripper {
        final List<Object[]> words = new ArrayList<Object[]>();
        WordStripper() throws IOException { super(); }
        @Override protected void writeString(String text, List<TextPosition> positions) throws IOException {
            if (positions == null || positions.isEmpty() || text == null || text.trim().length() == 0) return;
            words.add(new Object[] { Integer.valueOf(getCurrentPageNo()), Float.valueOf(positions.get(0).getYDirAdj()), text });
        }
    }

    private static class ImgFinder extends PDFStreamEngine {
        final JSONArray out;
        int page = 0;
        float pageH = 0;
        ImgFinder(JSONArray out) {
            this.out = out;
            addOperator(new Concatenate());
            addOperator(new DrawObject());
            addOperator(new SetGraphicsStateParameters());
            addOperator(new Save());
            addOperator(new Restore());
            addOperator(new SetMatrix());
        }
        @Override protected void processOperator(Operator operator, List<COSBase> operands) throws IOException {
            String name = operator.getName();
            if ("Do".equals(name) && operands.size() > 0 && operands.get(0) instanceof COSName) {
                PDXObject xobject = getResources().getXObject((COSName) operands.get(0));
                if (xobject instanceof PDImageXObject) {
                    PDImageXObject image = (PDImageXObject) xobject;
                    Matrix ctm = getGraphicsState().getCurrentTransformationMatrix();
                    float w = Math.abs(ctm.getScalingFactorX());
                    float h = Math.abs(ctm.getScalingFactorY());
                    float x = ctm.getTranslateX();
                    float y = ctm.getTranslateY();
                    if (out.length() < 150 && image.getWidth() >= 40 && image.getHeight() >= 40 && w >= 20 && h >= 20) {
                        try {
                            Bitmap bmp = image.getImage();
                            if (bmp != null) {
                                float k = Math.min(1f, 240f / (float) Math.max(bmp.getWidth(), bmp.getHeight()));
                                int nw = Math.max(1, Math.round(bmp.getWidth() * k));
                                int nh = Math.max(1, Math.round(bmp.getHeight() * k));
                                Bitmap dst = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888);
                                Canvas c = new Canvas(dst);
                                c.drawColor(Color.WHITE);
                                c.drawBitmap(bmp, null, new RectF(0, 0, nw, nh), new Paint(Paint.FILTER_BITMAP_FLAG));
                                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                                dst.compress(Bitmap.CompressFormat.JPEG, 75, bo);
                                JSONObject o = new JSONObject();
                                o.put("p", page);
                                o.put("y0", pageH - (y + h));
                                o.put("y1", pageH - y);
                                o.put("x0", x);
                                o.put("x1", x + w);
                                o.put("d", "data:image/jpeg;base64," + android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP));
                                out.put(o);
                                dst.recycle();
                            }
                        } catch (Throwable ignore) { }
                    }
                } else if (xobject instanceof PDFormXObject) {
                    showForm((PDFormXObject) xobject);
                }
            } else {
                super.processOperator(operator, operands);
            }
        }
    }

    private String readPdf(PDDocument doc) throws Exception {
        WordStripper ws = new WordStripper();
        ws.setSortByPosition(true);
        ws.getText(doc);
        JSONArray lines = new JSONArray();
        StringBuilder cur = new StringBuilder();
        int curP = -1;
        float curY = -1000f;
        for (Object[] w : ws.words) {
            int p = ((Integer) w[0]).intValue();
            float y = ((Float) w[1]).floatValue();
            if (cur.length() > 0 && (p != curP || Math.abs(y - curY) > 3.5f)) {
                JSONObject l = new JSONObject();
                l.put("p", curP); l.put("y", curY); l.put("t", cur.toString());
                lines.put(l);
                cur.setLength(0);
            }
            if (cur.length() == 0) { curP = p; curY = y; } else cur.append(' ');
            cur.append((String) w[2]);
        }
        if (cur.length() > 0) {
            JSONObject l = new JSONObject();
            l.put("p", curP); l.put("y", curY); l.put("t", cur.toString());
            lines.put(l);
        }
        JSONArray images = new JSONArray();
        try {
            ImgFinder finder = new ImgFinder(images);
            int n = doc.getNumberOfPages();
            for (int i = 0; i < n && i < 30; i++) {
                finder.page = i + 1;
                finder.pageH = doc.getPage(i).getMediaBox().getHeight();
                finder.processPage(doc.getPage(i));
            }
        } catch (Throwable ignore) { }
        JSONObject res = new JSONObject();
        res.put("lines", lines);
        res.put("images", images);
        res.put("err", "");
        return res.toString();
    }

    private void doSharePdf(String json, final String via, final String to, final String subject) {
        try {
            JSONObject j = new JSONObject(json);
            String safe = j.optString("file", "cotizacion").replaceAll("[^\\p{L}\\p{N} ._-]", "_") + ".pdf";
            File dir = new File(getCacheDir(), "exports");
            dir.mkdirs();
            File f = new File(dir, safe);
            new PdfMaker(this).build(j, f);
            final Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            final String text = j.optString("numero") + " - " + j.optString("nombre");
            runOnUiThread(new Runnable() { @Override public void run() { sendPdf(uri, via, to, subject, text); } });
        } catch (Exception e) {
            runOnUiThread(new Runnable() { @Override public void run() {
                Toast.makeText(MainActivity.this, "No se pudo crear el PDF", Toast.LENGTH_LONG).show();
            }});
        }
    }

    private void sendPdf(Uri uri, String via, String to, String subject, String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.putExtra(Intent.EXTRA_TEXT, text);
        i.setClipData(ClipData.newRawUri("", uri));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if ("wa".equals(via)) {
            i.setPackage("com.whatsapp");
            try { startActivity(i); return; } catch (Exception e) { i.setPackage(null); }
            startActivity(Intent.createChooser(i, "Enviar PDF"));
        } else {
            if (to != null && to.length() > 0) i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
            i.putExtra(Intent.EXTRA_SUBJECT, subject);
            startActivity(Intent.createChooser(i, "Enviar PDF por correo"));
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
